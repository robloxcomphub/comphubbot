# Discord License Bot

This bot interacts with a license management API. Built with Node.js + Discord.js.

## Usage

- Add your `.env` file with your Discord bot token and API key.
- Run `npm install`
- Run `npm start`

## Commands

```
!genkey
!resethwid
!fetchkey
...etc.
```
